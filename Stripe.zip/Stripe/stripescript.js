$(document).ready(function() {
    $.ajax({
      type: 'GET',
      url: 'https://jsonblob.com/api/jsonBlob/6766327f-607d-11e9-95ef-9bcb815ba4a4',
      contentType: "application/json",
      dataType: 'json',
      async: true,
      crossDomain: true,
      success: function (data) {
	
	for (var item in data) { 
    	var _menu = "";
        var _submenuData = data[item];
        if(_submenuData.length > 0) {
        	var _submenu = "";
            
        	for(var i = 0; i < _submenuData.length; i++) {
            	_submenu += "<a class='dropdown-item'>" + _submenuData[i]["title"] +"<br/>"+ _submenuData[i]["sub-title"] +"</a>";
        }
        
        _menu = "<li class='nav-item dropdown'>"
        		    + "<a class='nav-link' href='' id='navbardrop' data-toggle='dropdown'> "
                + item.replace(/^\w/, c => c.toUpperCase()) + " </a>"
                + "<div id='drop' class='dropdown-menu'>"
                + _submenu
				+ "</div>"
                + "</li>";
        }
        else {
        	_menu = "<li class='nav-item'>"
        		+ "<a class='nav-link' href=''> " + item.replace(/^\w/, c => c.toUpperCase()) + " </a>"
                + "</li>";
        }
        
        $("#navbarId").append(_menu);
    }
     },
      error: function (e) {
        console.log("There was an error with your request...");
        console.log("error: " + JSON.stringify(e));
      }
    });

});